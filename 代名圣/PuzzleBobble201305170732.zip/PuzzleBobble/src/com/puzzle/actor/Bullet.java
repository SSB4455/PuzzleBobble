package com.puzzle.actor;

import com.game.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.util.Log;

public class Bullet extends GameActor{
	
	public static Bitmap [] normal_bullet = new Bitmap[8];
	public static Bitmap [] frozen_bullet = new Bitmap[8];
	public static Bitmap [] blind_bullet = new Bitmap[8];
	public static int radius;
	//���䵯��ķ���
	public static final int DIRECTION_LEFT = -1;
	public static final int DIRECTION_UP = 0;
	public static final int DIRECTION_RIGHT = 1;
	public static final int DIRECTION_DOWN = 2;
	public static final int DIRECTION_STOP = 3;
	
	double shootAngle;
	boolean shooting, isCollsion;
	
	int speed, type, direction;
	ArcNode nextArc;
	
	
	
	public Bullet(float x, float y, int type, String name, Context context) {
		super(name);
		for(int i = 0; i < 8; i++) {
			normal_bullet[i] = BitmapFactory.decodeResource(context.getResources(), R.drawable.bubble_1 + i);
			frozen_bullet[i] = BitmapFactory.decodeResource(context.getResources(), R.drawable.frozen_1 + i);
			blind_bullet[i] = BitmapFactory.decodeResource(context.getResources(), R.drawable.blind_1 + i);
		}
		
		actorX = x;
		actorY = y;
		radius = normal_bullet[0].getHeight() / 2;
		
		actorBitmap = normal_bullet[type];
		speed = actorBitmap.getWidth();
		direction = DIRECTION_STOP;
		
		setType(type);
		
		shooting = false;
		isCollsion = false;
	}
	
	public void logic(long elapsedTime){
		if(!isCollsion){
			if(actorY > GameMap.GAME_AREA_TOP){
				actorY -= speed * Math.cos(shootAngle * Math.PI / 180) * elapsedTime / 100;
				if(direction == DIRECTION_RIGHT)
					actorX += speed * Math.sin(shootAngle * Math.PI/180) * elapsedTime / 100;
				else if(direction == DIRECTION_LEFT)
					actorX -= speed * Math.sin(shootAngle*Math.PI/180) * elapsedTime / 100;
			}else 
				actorY = GameMap.GAME_AREA_TOP;
			
			if(direction == DIRECTION_DOWN){
				actorY += 2 * speed * elapsedTime / 100;
			}
			
			if(actorX > GameMap.GAME_AREA_RIGHT){
				direction = DIRECTION_LEFT;
				actorX = GameMap.GAME_AREA_RIGHT;
			}else if(actorX < GameMap.GAME_AREA_LEFT){
				direction = DIRECTION_RIGHT;
				actorX = GameMap.GAME_AREA_LEFT;
			}
		}
	}
	
	public void myDraw(Canvas canvas){
		
		canvas.drawBitmap(actorBitmap, (int)actorX - radius, (int)actorY - radius, paint);
	}
	
	public boolean isCollsionWith(GameMap gameMap) {
		if(actorY <= GameMap.GAME_AREA_TOP) {
			actorY = GameMap.GAME_AREA_TOP;
			isCollsion = true;
			return true;
		}
		
		for(GameActor bullets : gameMap.children) {
			float distance2 = (actorX - bullets.actorX) * (actorX - bullets.actorX) + (actorY - bullets.actorY) * (actorY - bullets.actorY);
			if(distance2 < radius * radius * 3.9) {
				actorX = (float) ((actorX - bullets.actorX) * 2 * radius / Math.sqrt(distance2)) + bullets.actorX;
				actorY = (float) ((actorY - bullets.actorY) * 2 * radius / Math.sqrt(distance2)) + bullets.actorY;
				
				isCollsion = true;
				Log.i("Bullet-" + name, "collsion with " + bullets.name + bullets.level);
				return true;
			}
			
		}
		
		return false;
	}
	
	void startShoot(double angle){
		shooting = true;
		shootAngle = Math.abs(angle);
		
		if(angle >= 0)
			direction = DIRECTION_RIGHT;
		else if(angle < 0)
			direction = DIRECTION_LEFT;
		else 
			direction = DIRECTION_UP;
	}
	
	public boolean addArc(ArcNode arcNode) {
		if(nextArc == null)
			nextArc = arcNode;
		else{
			ArcNode a = nextArc;
			while(a.hasNext())
				a = a.nextArc();
			a.nextArc = arcNode;
		}
		return true;
	}

	boolean deleteArc(ArcNode arcNode) {
		
		return false;
	}
	
	public void setBitmap_bullet(Bitmap bitmap_bullet) {
		this.actorBitmap = bitmap_bullet;
	}
	
	public Bitmap getBitmap_bullet() {
		return actorBitmap;
	}
	
	public void setType(int type) {
		if(type < 0 || type > 7)
			this.type = 0;
		else
			this.type = type;
		actorBitmap = normal_bullet[this.type];
	}
	
	public int getType() {
		return type;
	}
	
	float setX(float x){
		actorX = x;
		return actorX;
	}
	
	float setY(float y){
		actorY = y;
		return actorY;
	}
	
}
