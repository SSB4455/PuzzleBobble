package com.puzzle.actor;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class ArcNode {
	Bullet bullet;
	ArcNode nextArc;
	
	
	
	public ArcNode(Bullet bullet) {
		//nextArc = null;
		this.bullet = bullet;
	}
	
	boolean hasNext() {
		if(nextArc != null)
			return true;
		return false;
		
	}
	
	ArcNode nextArc() {
		return nextArc;
	}
	
}
