package com.puzzle.actor;

import com.puzzle.MyGameSurfaceView;
import com.puzzle.actor.Bullet;

import android.graphics.Canvas;
import android.util.Log;

public class GameMap extends GameActor{
	//��Ļ�߽�
	public static int GAME_AREA_TOP;
	public static int GAME_AREA_LEFT;
	public static int GAME_AREA_RIGHT;
	public static int GAME_AREA_BOTTOM;
	
	
	
	public GameMap(String name) {
		super(name);
		GAME_AREA_TOP = MyGameSurfaceView.screenH / 16 + Bullet.radius;
		GAME_AREA_BOTTOM = MyGameSurfaceView.screenH * 19 / 24 - Bullet.radius;
		GAME_AREA_LEFT = MyGameSurfaceView.screenW * 1 / 16 + Bullet.radius;
		GAME_AREA_RIGHT = MyGameSurfaceView.screenW * 29 / 32 - Bullet.radius;
		
	}
	
	public void logic(long elapsedTime){
		
	}
	
	public void myDraw(Canvas canvas){
		
		super.myDraw(canvas);
		
	}

	@Override
	public void addChild(GameActor actor) {
		
		int radius = Bullet.radius;
		
		for(GameActor bullets : children) {
			float distance2 = (actor.actorX - bullets.actorX) * (actor.actorX - bullets.actorX) + (actor.actorY - bullets.actorY) * (actor.actorY - bullets.actorY);
			if(distance2 < radius * radius * 5) {
				actor.actorX = (float) ((actor.actorX - bullets.actorX) * 2 * radius / Math.sqrt(distance2)) + bullets.actorX;
				actor.actorY = (float) ((actor.actorY - bullets.actorY) * 2 * radius / Math.sqrt(distance2)) + bullets.actorY;
				
				Log.i("Bullet-" + name, "add with " + bullets.name + bullets.level);
				break;
			}
		}
		
		super.addChild(actor);
	}
	
	float setX(float x){
		actorX = x;
		return actorX;
	}
	
	float setY(float y){
		actorY = y;
		return actorY;
	}
	
}
