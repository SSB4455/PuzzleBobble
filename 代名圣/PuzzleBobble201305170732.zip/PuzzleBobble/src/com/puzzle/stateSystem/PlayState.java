package com.puzzle.stateSystem;

import com.game.R;
import com.puzzle.actor.Bullet;
import com.puzzle.actor.GameActor.ActorStatus;
import com.puzzle.actor.GameMap;
import com.puzzle.actor.Shooter;
import com.puzzle.MyGameSurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.widget.Toast;
import android.util.Log;

public class PlayState implements IGameObject {
	
	private StateSystem stateSystem;
	
	private int screenW, screenH;
	
	private GameMap gameMap;
	private Shooter shooter;
	
	Rect src;
	private Bitmap backGround;
	
	Paint paint;
	
	
	
	public PlayState(Context context, StateSystem stateSystem, SurfaceHolder sfh) {
		this.stateSystem = stateSystem;
		
		screenW = sfh.getSurfaceFrame().right;
		screenH = sfh.getSurfaceFrame().bottom;
		
		backGround = BitmapFactory.decodeResource(context.getResources(), R.drawable.background);
		backGround = Bitmap.createBitmap(backGround, backGround.getWidth()/4, 0, backGround.getWidth()/2, backGround.getHeight());
		src = new Rect(0, 0, backGround.getWidth(), backGround.getHeight());
		
		new Bullet(0, 0, 0, "bullet", context);
		gameMap = new GameMap("GameMap");
		shooter = new Shooter(gameMap, context);
		
		paint = new Paint();
		paint.setColor(Color.WHITE);
	}
	
	public void logic(long elapsedTime) {
		shooter.logic(elapsedTime);
		gameMap.logic(elapsedTime);
		
	}
	
	public void myDraw(Canvas canvas) {
		canvas.drawColor(Color.BLACK);		//��һ¶�� ��ɫ����
		canvas.drawBitmap(backGround, src, MyGameSurfaceView.dst, paint);		//������

		shooter.myDraw(canvas, paint);
		gameMap.myDraw(canvas);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Log.i("PlayState", "onKeyDown ����> back");
			gameMap.changeStatus(ActorStatus.Dead);
			gameMap.cleanUpDead();
			stateSystem.changeState("MenuState");
		}
		return true;
	}
	
	public boolean onTouchEvent(MotionEvent event) {
		shooter.onTouchEvent(event);
		return true;
	}
	
	@Override
	public void render() {
		// TODO Auto-generated method stub
	}
	
}
