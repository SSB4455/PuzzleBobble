package com.puzzle;

import com.puzzle.actor.Bullet;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;

public class Shooter {
	private int x, y;
	public static int shooterH, shooterW;
	public static float angle;
	
	private boolean shooting;
	private float shootAngle;
	
	private Bullet shoot, prepare1, prepare2;
	private Bitmap shooter;
	
	
	
	public Shooter(Bitmap shooter) {
		this.shooter = shooter;
		shooterW = shooter.getWidth();
		shooterH = shooter.getHeight();
		x = MyGameSurfaceView.screenW / 2;
		y = MyGameSurfaceView.screenH - shooterH / 3 * 2;
		
		shooting = false;
		
		angle = 0;
		
	}
	
	public void myDraw(Canvas canvas, Paint paint){
		
		//����һ������ĽǶȵ���ʾ
		canvas.save();
		canvas.rotate(angle, x, y);
		canvas.drawBitmap(shooter, x - shooterW / 2, y - shooterH / 2, paint);
		canvas.restore();
		
	}
	
	public boolean onTouchEvent(MotionEvent event) {
		
		int touchX = (int)event.getX();
		int touchY = (int)event.getY();
		
		if(event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE){
			if(touchY < y)
				angle = (float) (Math.atan2((touchX - x), (y - touchY)) * 180 / Math.PI);
		}
				
		if(event.getAction() == MotionEvent.ACTION_UP){
			
			if(!shooting) {
				shooting = true;
				shootAngle = angle;
			}
			//�������Ƕ�
			Log.i("Shooter", ", shootAngle = " + shootAngle + "\t touchX = " + touchX + ", touchY = " + touchY);
		}
		return true;
	}

}
