package com.puzzle.stateSystem;

import com.game.R;
import com.puzzle.MyGameSurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.SoundPool;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.widget.Toast;
import android.util.Log;

public class PlayState implements IGameObject {
	
	private Context context;
	private StateSystem stateSystem;
	
	private int screenW, screenH, touchMusic;
	private long exitTime;
	
	Rect src;
	private Bitmap backGround;
	
	Paint paint;
	
	
	
	public PlayState(Context context, StateSystem stateSystem, SurfaceHolder sfh) {
		this.context = context;
		this.stateSystem = stateSystem;
		
		screenW = sfh.getSurfaceFrame().right;
		screenH = sfh.getSurfaceFrame().bottom;
		
		backGround = BitmapFactory.decodeResource(context.getResources(), R.drawable.background);
		backGround = Bitmap.createBitmap(backGround, backGround.getWidth()/4, 0, backGround.getWidth()/2, backGround.getHeight());
		
		src = new Rect(0, 0, backGround.getWidth()/2, backGround.getHeight());
		
		paint = new Paint();
		paint.setColor(Color.WHITE);
	}
	
	public void logic(long elapsedTime) {
		// TODO Auto-generated method stub
		
	}
	
	public void myDraw(Canvas canvas) {
		canvas.drawColor(Color.BLACK);		//�����ɫ¶��
		canvas.drawBitmap(backGround, src, MyGameSurfaceView.dst, paint);		//������
		canvas.save();		//������������ʾ����
		
		//canvas.drawBitmap(menuBackground, 0, 0, paint);
		canvas.restore();
	}
	
	public boolean onTouchEvent(MotionEvent event) {
		
		return true;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public void render() {
		// TODO Auto-generated method stub
		
	}
	
}
