/** Automatically generated file. DO NOT MODIFY */
package ldp.games.dragon;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}