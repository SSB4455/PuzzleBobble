package com.puzzle;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;

public class Shooter {
	private Bitmap shooter;

	private int x, y;
	public static int shooterH, shooterW;
	public static float angel ;
	

	public Shooter(Bitmap shooter) {
		this.shooter = shooter;
		shooterW = shooter.getWidth();
		shooterH = shooter.getHeight();
		x = MyGameSurfaceView.screenW / 2;
		y = MyGameSurfaceView.screenH - shooterH / 3 * 2;
		
		angel =0;
	}
	public void MyDraw(Canvas canvas, Paint paint){
		
		//����һ������ĽǶȵ���ʾ
		canvas.save();
		canvas.rotate(angel, x, y);
		canvas.drawBitmap(shooter, x - shooterW / 2, y - shooterH / 2, paint);
		canvas.restore();
		
	}
	public boolean onTouchEvent(MotionEvent event) {
		
		int pressX = (int)event.getX();
		int pressY = (int) event.getY();
		
		if(event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE){
			if(Bullet.isshoot == false){
				if(pressY < y)
					angel = (float) (Math.atan2((pressX - x), (y - pressY)) * 180 / Math.PI);
			}
		}
				
		if(event.getAction() == MotionEvent.ACTION_UP){
			//��ʾ����Ƕ�
			Log.i("Shooter", "shoot angel pressX = " + pressX + ", pressY = " + pressY + ", angel = " + angel + ", x = " + x + ", y = " + y);
		}
		return true;
	}

}
