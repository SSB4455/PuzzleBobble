package com.puzzle;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Gaming {
	Rect src;
	Rect dst;
	private Bitmap backGround;
	public Gaming(Bitmap backGround) {
		
		//�˴��ܹ����� ����������ٿ���
		src = new Rect(0, 0, backGround.getWidth()/2, backGround.getHeight());
		dst = new Rect(0, 0, MyGameSurfaceView.screenW, MyGameSurfaceView.screenH);
		this.backGround = Bitmap.createBitmap(backGround, backGround.getWidth()/4, 0, backGround.getWidth()/2, backGround.getHeight());
		
	}
	
	public void myDraw(Canvas canvas, Paint paint) {
		
		canvas.drawBitmap(backGround, src, dst, paint);
	}
}
