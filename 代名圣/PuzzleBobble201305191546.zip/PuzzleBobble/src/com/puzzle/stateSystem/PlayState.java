package com.puzzle.stateSystem;

import com.game.R;
import com.puzzle.actor.Bullet;
import com.puzzle.actor.GameActor.ActorStatus;
import com.puzzle.actor.GameMap;
import com.puzzle.actor.Position;
import com.puzzle.actor.Shooter;
import com.puzzle.MyGameSurfaceView;
import com.puzzle.PuzzleBobbleActivity;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.widget.Toast;
import android.util.Log;

public class PlayState implements IGameObject {
	
	private StateSystem stateSystem;
	
	private GameMap gameMap;
	private Shooter shooter;
	
	Rect src;
	private Bitmap backGround;
	private Builder builder;
	
	Paint paint;
	
	
	
	public PlayState(final Context context, final StateSystem stateSystem, SurfaceHolder sfh) {
		this.stateSystem = stateSystem;
		
		backGround = BitmapFactory.decodeResource(context.getResources(), R.drawable.background);
		backGround = Bitmap.createBitmap(backGround, backGround.getWidth()/4, 0, backGround.getWidth()/2, backGround.getHeight());
		src = new Rect(0, 0, backGround.getWidth(), backGround.getHeight());
		
		new Bullet(new Position(0f, 0f), 0, "bullet", context);
		gameMap = new GameMap("GameMap");
		shooter = new Shooter(gameMap, context);
		
		
		/*builder.setPositiveButton("����һ��", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					//Toast.makeText(context, "���¿�ʼ", Toast.LENGTH_SHORT).show();
					gameMap = new GameMap("GameMap");
				}
			}
		);
		builder.setPositiveButton("����", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					//Toast.makeText(context, "����", Toast.LENGTH_SHORT).show();
					gameMap.changeStatus(ActorStatus.Dead);
					gameMap.cleanUpDead();
					//stateSystem.changeState("MenuState");
				}
			}
		);*/
		
		paint = new Paint();
		paint.setColor(Color.WHITE);
	}
	
	public void logic(long elapsedTime) {
		if(!isWin() && !isLose()) {
			shooter.logic(elapsedTime);
			gameMap.logic(elapsedTime);
			
		}
		
		
	}
	
	public void myDraw(Canvas canvas) {
		canvas.drawColor(Color.BLACK);		//��һ¶�� ��ɫ����
		canvas.drawBitmap(backGround, src, MyGameSurfaceView.dst, paint);		//������
		
		if(!isWin() && !isLose()) {
			shooter.myDraw(canvas, paint);
			gameMap.myDraw(canvas);
		}
	}
	
	public boolean isWin() {
		if(gameMap.size() == 0)
			return true;
		return false;
	}
	
	public boolean isLose() {
		
		return false;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Log.i("PlayState", "onKeyDown ����> back");
			gameMap.changeStatus(ActorStatus.Dead);
			gameMap.cleanUpDead();
			stateSystem.changeState("MenuState");
		}
		return true;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		shooter.onTouchEvent(event);
		return true;
	}
	
	@Override
	public void render() {
		// TODO Auto-generated method stub
	}
	
}
