package com.puzzle.actor;

import java.util.ArrayList;
import java.util.List;

import com.puzzle.MyGameSurfaceView;
import com.puzzle.actor.Bullet;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;

public class GameMap extends GameActor{
	//��Ļ�߽�
	public static int GAME_AREA_TOP;
	public static int GAME_AREA_LEFT;
	public static int GAME_AREA_RIGHT;
	public static int GAME_AREA_BOTTOM;
	
	int s;
	
	List<GameActor> positions;
	GameActor bing;
	
	
	
	public GameMap(String name) {
		super(name);
		GAME_AREA_TOP = MyGameSurfaceView.screenH / 16 + Bullet.radius;
		GAME_AREA_BOTTOM = MyGameSurfaceView.screenH * 19 / 24 - Bullet.radius;
		GAME_AREA_LEFT = MyGameSurfaceView.screenW * 1 / 16 + Bullet.radius;
		GAME_AREA_RIGHT = MyGameSurfaceView.screenW * 29 / 32 - Bullet.radius;
		
		s = 0;
		positions = new ArrayList<GameActor>();
		bing = new GameActor("bing");
		for(int i = 0; GAME_AREA_TOP + Bullet.radius * 1.732 * i < GAME_AREA_BOTTOM; i++){
			for(int j = 0; ; j++){
				GameActor a = new GameActor(i + "," + j + "  ");
				a.actorX = (float) (GAME_AREA_LEFT + Bullet.radius * 2 * j);
				a.actorY = (float) (GAME_AREA_TOP + Bullet.radius * Math.sqrt(3) * i);
				a.actorX += (i % 2 == 0) ? 0 : Bullet.radius;
				if(a.actorX < GAME_AREA_RIGHT)
					positions.add(a);
				else
					break;
			}
		}
		
		paint = new Paint();
	}
	
	public void logic(long elapsedTime) {
		bing.logic(elapsedTime);
	}
	
	public void myDraw(Canvas canvas) {
		super.myDraw(canvas);
		bing.myDraw(canvas);
		
		/*��ʾ����С���
		for(GameActor a : position)
			canvas.drawCircle(a.actorX, a.actorY, 1, paint);
		*/
	}
	
	@Override
	public void addChild(GameActor actor) {
		
		float distance23 = Bullet.radius * Bullet.radius * 10;
		GameActor nearly = positions.get(0);
		for(GameActor position : positions) {
			float distance2 = (actor.actorX - position.actorX) * (actor.actorX - position.actorX) + (actor.actorY - position.actorY) * (actor.actorY - position.actorY);
			if(distance2 < distance23) {
				distance23 = distance2;
				nearly = position;
			}
		}
		actor.actorX = nearly.actorX;
		actor.actorY = nearly.actorY;
		((Bullet) actor).hasARoot = true;
		actor.name = s++ + "-" + actor.name + "-" + ((Bullet) actor).type;
		super.addChild(actor);
		
		//Ϊactor�Լ��������ڵ����������ٽӱ�
		for(GameActor bullets : this.children) {
			float distance2 = (actor.actorX - bullets.actorX) * (actor.actorX - bullets.actorX) + (actor.actorY - bullets.actorY) * (actor.actorY - bullets.actorY);
			if(distance2 < Bullet.radius * Bullet.radius * 4.2) {
				if(bullets != actor) {
					((Bullet) actor).addArc(new ArcNode((Bullet) bullets));
					((Bullet) bullets).addArc(new ArcNode((Bullet) actor));
					Log.i("GameMap.addChile", "actor add arc to -> " + bullets.name);
				}
			}
		}
		((Bullet) actor).showArcLink();
		
		bing.children.clear();
		findSameColor(actor);	//����actor��ͬɫ�����ݷŵ�bing����
		checkBing();		//��gameMap�����bing�ڵ�����ɾ�� ������������ ʹ֮����
	}
	
	void findSameColor(GameActor actor) {
		bing.addChild(actor);
		
		int radius = Bullet.radius;
		for(GameActor bullets : this.children) {
			float distance2 = (actor.actorX - bullets.actorX) * (actor.actorX - bullets.actorX) + (actor.actorY - bullets.actorY) * (actor.actorY - bullets.actorY);
			if(distance2 < radius * radius * 4.2 && ((Bullet) actor).getType() == ((Bullet) bullets).getType()) {
				if(!bing.children.contains(bullets))
					findSameColor(bullets);
			}
		}
	}
	
	void checkBing() {
		int countBing = bing.children.size();
		
		if(countBing > 2) {
			for(GameActor bingActor : bing.children) {
				ArcNode arcNode = ((Bullet) bingActor).nextArc;
				while(arcNode != null) {
					//��ͨ����ȥ����һ�����ݵĻ���ɾ��
					arcNode.bullet.deleteArc(new ArcNode((Bullet) bingActor));
					arcNode = arcNode.nextArc();
				}
				((Bullet) bingActor).direction = Bullet.DIRECTION_DOWN;
				((Bullet) bingActor).isCollsion = false;
				this.children.remove(bingActor);
			}
		}else
			bing.children.clear();		//���û�дչ�������ֱ�����bing��������
		
		
		//֮����Ҫ�ٴ�ѭ�� ����Ϊ���ڲ���gameMap�а�������������ȥ���ݵĻ�ɾ���� ���ܹ���ɾ���߼������� ������������		GameActor bing2 = new GameActor("bing2");
		for(int i = 0; i < bing.children.size(); i++) {
			GameActor bingActor = bing.children.get(i);
			ArcNode arcNode = ((Bullet) bingActor).nextArc;
			((Bullet) bingActor).showArcLink();
			while(arcNode != null) {
				arcNode.bullet.showArcLink();
				if(!hasARoot(arcNode.bullet)) {
					Log.i("GameMap-chechBing", arcNode.bullet.name + " no root");
					arcNode.bullet.direction = Bullet.DIRECTION_DOWN;
					arcNode.bullet.isCollsion = false;
					if(!bing.children.contains(arcNode.bullet))		//���������ݲ���bing�����ټӽ��� ��Ȼ����Զѭ��
						bing.addChild(arcNode.bullet);
					this.children.remove(arcNode.bullet);
				}
				arcNode = arcNode.nextArc();
			}
		}
	}
	
	boolean hasARoot(Bullet bullet) {		//�ж����������û�и� ���Ǳ�׼�ݹ�
		if(bullet.actorY == positions.get(0).actorY)
			return true;
		
		ArcNode arcNode = bullet.nextArc;
		while(arcNode != null) {
			if(hasARoot(arcNode.bullet))
				return true;
			arcNode = arcNode.nextArc();
		}
		
		return false;
	}
	
}
