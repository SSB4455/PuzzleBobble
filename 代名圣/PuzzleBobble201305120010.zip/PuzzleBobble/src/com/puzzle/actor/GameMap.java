package com.puzzle.actor;

import com.game.R;
import com.puzzle.MyGameSurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.util.Log;

public class GameMap extends GameActor{
	
	private long exitTime;
	
	
	
	
	public GameMap(String name) {
		super(name);
	}
	
	public void logic(long elapsedTime){
		
	}
	
	public void myDraw(Canvas canvas){
		
		super.myDraw(canvas);
		
	}
	
	public Bitmap getBitmap_bullet() {
		return actorBitmap;
	}
	
	float setX(float x){
		actorX = x;
		return actorX;
	}
	
	float setY(float y){
		actorY = y;
		return actorY;
	}
	
}
