package com.puzzle;

public class GameMap {
	public static int[][] map = {
		{6,6,4,4,2,2,3,3},
		{0,6,6,4,4,2,2,3},
		{2,2,3,3,6,6,4,4},
		{2,3,3,6,6,4,4,0}
	};

}
