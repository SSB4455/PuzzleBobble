package com.puzzle.actor;

import java.util.ArrayList;
import java.util.List;

import com.puzzle.MyGameSurfaceView;
import com.puzzle.actor.Bullet;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;

public class GameMap extends GameActor{
	//��Ļ�߽�
	public static int GAME_AREA_TOP;
	public static int GAME_AREA_LEFT;
	public static int GAME_AREA_RIGHT;
	public static int GAME_AREA_BOTTOM;
	
	List<GameActor> positions;
	GameActor bing;
	
	
	
	public GameMap(String name) {
		super(name);
		GAME_AREA_TOP = MyGameSurfaceView.screenH / 16 + Bullet.radius;
		GAME_AREA_BOTTOM = MyGameSurfaceView.screenH * 19 / 24 - Bullet.radius;
		GAME_AREA_LEFT = MyGameSurfaceView.screenW * 1 / 16 + Bullet.radius;
		GAME_AREA_RIGHT = MyGameSurfaceView.screenW * 29 / 32 - Bullet.radius;
		
		positions = new ArrayList<GameActor>();
		bing = new GameActor("bing");
		for(int i = 0; GAME_AREA_TOP + Bullet.radius * 1.732 * i < GAME_AREA_BOTTOM; i++){
			for(int j = 0; ; j++){
				GameActor a = new GameActor(i + "," + j + "  ");
				a.actorX = (float) (GAME_AREA_LEFT + Bullet.radius * 2 * j);
				a.actorY = (float) (GAME_AREA_TOP + Bullet.radius * Math.sqrt(3) * i);
				a.actorX += (i % 2 == 0) ? 0 : Bullet.radius;
				if(a.actorX < GAME_AREA_RIGHT)
					positions.add(a);
				else
					break;
			}
		}
		
		paint = new Paint();
	}
	
	public void logic(long elapsedTime) {
		bing.logic(elapsedTime);
	}
	
	public void myDraw(Canvas canvas) {
		super.myDraw(canvas);
		bing.myDraw(canvas);
		
		/*��ʾ����С���
		for(GameActor a : position)
			canvas.drawCircle(a.actorX, a.actorY, 1, paint);
		*/
	}
	
	@Override
	public void addChild(GameActor actor) {
		bing.children.clear();
		
		float distance2 = Bullet.radius * Bullet.radius * 10;
		GameActor nearly = positions.get(0);
		for(GameActor position : positions) {
			float distance22 = (actor.actorX - position.actorX) * (actor.actorX - position.actorX) + (actor.actorY - position.actorY) * (actor.actorY - position.actorY);
			if(distance22 < distance2) {
				distance2 = distance22;
				nearly = position;
			}
		}
		actor.actorX = nearly.actorX;
		actor.actorY = nearly.actorY;
		super.addChild(actor);
		//Log.i("Bullet-" + name, "add with " + nearly.name + bullets.level);
		
		findBing(actor);
		checkBing(actor);
	}
	
	void findBing(GameActor actor) {
		bing.addChild(actor);
		
		int radius = Bullet.radius;
		for(GameActor bullets : this.children) {
			float distance2 = (actor.actorX - bullets.actorX) * (actor.actorX - bullets.actorX) + (actor.actorY - bullets.actorY) * (actor.actorY - bullets.actorY);
			if(distance2 < radius * radius * 4.2 && ((Bullet) actor).getType() == ((Bullet) bullets).getType()) {
				if(!bing.children.contains(bullets))
					findBing(bullets);
			}
		}
	}
	
	void checkBing(GameActor actor) {
		int countBing = bing.children.size();
		
		if(countBing > 2){
			for(GameActor a : bing.children){
				((Bullet) a).direction = Bullet.DIRECTION_DOWN;
				((Bullet) a).isCollsion = false;
				this.children.remove(a);
			}
		}
		
		/*GameActor notIsolated = new GameActor("map");	//�и���С��Ҫ���ӵ�������
		//���ܹ����ʵ�����С��ӷ���map
		//��this�б�map���Ԫ��(����Ԫ��)���뵽bing
		
		for(GameActor a : this.children) {
			if(hasARoot(a, notIsolated))
				continue;
			((Bullet) a).direction = Bullet.DIRECTION_DOWN;
			((Bullet) a).isCollsion = false;
			//this.children.remove(a);
			bing.children.add(a);
		}*/
		
	}
	
	boolean hasARoot(GameActor actor, GameActor notIsolated) {
		if(notIsolated.children.contains(actor))
			return true;
		
		for(GameActor bullets : this.children){
			float distance2 = (actor.actorX - bullets.actorX) * (actor.actorX - bullets.actorX) + (actor.actorY - bullets.actorY) * (actor.actorY - bullets.actorY);
			if(distance2 < Bullet.radius * Bullet.radius * 4.2) {
				if(!notIsolated.children.contains(bullets))
					hasARoot(bullets, notIsolated);
			}
		}
		
		return false;
	}
	
}
