package com.puzzle.actor;

import java.util.ArrayList;
import java.util.List;

import com.puzzle.MyGameSurfaceView;
import com.puzzle.actor.Bullet;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;

public class GameMap extends GameActor{
	//��Ļ�߽�
	public static int GAME_AREA_TOP;
	public static int GAME_AREA_LEFT;
	public static int GAME_AREA_RIGHT;
	public static int GAME_AREA_BOTTOM;
	
	List<GameActor> position;
	
	
	
	public GameMap(String name) {
		super(name);
		GAME_AREA_TOP = MyGameSurfaceView.screenH / 16 + Bullet.radius;
		GAME_AREA_BOTTOM = MyGameSurfaceView.screenH * 19 / 24 - Bullet.radius;
		GAME_AREA_LEFT = MyGameSurfaceView.screenW * 1 / 16 + Bullet.radius;
		GAME_AREA_RIGHT = MyGameSurfaceView.screenW * 29 / 32 - Bullet.radius;
		
		position = new ArrayList<GameActor>();
		for(int i = 0; GAME_AREA_TOP + Bullet.radius * 1.732 * i < GAME_AREA_BOTTOM; i++){
			for(int j = 0; ; j++){
				GameActor a = new GameActor(i + "," + j + "  ");
				a.actorX = (float) (GAME_AREA_LEFT + Bullet.radius * 2 * j);
				a.actorY = (float) (GAME_AREA_TOP + Bullet.radius * Math.sqrt(3) * i);
				a.actorX += (i % 2 == 0) ? 0 : Bullet.radius;
				if(a.actorX < GAME_AREA_RIGHT)
					position.add(a);
				else
					break;
			}
		}
		
		paint = new Paint();
	}
	
	public void logic(long elapsedTime) {
		
	}
	
	public void myDraw(Canvas canvas) {
		super.myDraw(canvas);
		for(GameActor a : position)
			canvas.drawCircle(a.actorX, a.actorY, 1, paint);
	}

	@Override
	public void addChild(GameActor actor) {
		
		float distance2 = Bullet.radius * Bullet.radius * 10;
		GameActor nearly = position.get(0);
		for(GameActor bullets : position) {
			float distance22 = (actor.actorX - bullets.actorX) * (actor.actorX - bullets.actorX) + (actor.actorY - bullets.actorY) * (actor.actorY - bullets.actorY);
			if(distance22 < distance2) {
				distance2 = distance22;
				nearly = bullets;
				//Log.i("Bullet-" + name, "add with " + bullets.name + bullets.level);
			}
		}
		actor.actorX = nearly.actorX;
		actor.actorY = nearly.actorY;
		
		super.addChild(actor);
	}
	
}
